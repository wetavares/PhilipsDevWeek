package com.dio_class.devweek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevweekApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevweekApplication.class, args);
	}

}
