package com.dio_class.devweek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevweekApplicationTests {

	@Test
	void contextLoads() {
	}

}
